<?php $__env->startSection('content'); ?>

<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
               <?php echo $__env->make('template-part.event_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               
            </div>
            <div class="col-lg-9">
                <div class="page_title">
                    <h2><?php echo e($data['page_title']); ?></h2>
                </div>
                <div class="page_content">
                    <?php if($data['events']->count()>0): ?>
                    <?php //var_dump($data['events']); exit; ?>
                    <div class="event_list">
                        <div class="row">
                            <?php $__currentLoopData = $data['events']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="col-lg-4">
                                <a href="<?php echo e(url('event-details/'.$event->slug)); ?>">
                                    <div class="event_box">
                                    <?php
                                    if(!empty($event->event_image)){
                                        $bg_img= url($event->event_image);
                                    } else{
                                        $bg_img= '';
                                    }
                                    ?>
                                        <div class="event_feature_image" style="background-image: url(<?php echo e($bg_img); ?>);">
                                           
                                        </div>
                                        <div class="event_title">
                                            <?php echo e($event->event_title); ?>

                                        </div>
                                        <div class="event_state">
                                            <span class="pull-left">
                                                <?php echo e($event->event_country); ?>

                                            </span>
                                            <span class="pull-right">
                                                <?php echo e(Helper::date_formate_change($event->event_date_start)); ?>

                                            </span>
                                            
                                        </div>
                                    </div>
                                </a>
                                
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="pagination_lonk_div">
                            <?php echo e($data['events']->links()); ?>

                        </div>
                    </div>
                    <?php else: ?>
                        <h5>No Event found!</h5>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coregen1/www/expodisco/resources/views/event_vertical_list.blade.php ENDPATH**/ ?>