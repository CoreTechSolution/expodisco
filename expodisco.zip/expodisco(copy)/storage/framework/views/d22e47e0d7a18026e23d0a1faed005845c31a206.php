<?php $__env->startSection('content'); ?>
    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                   <?php echo $__env->make('template-part.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   
                </div>
                <div class="col-lg-9">
                    Thak you to Login as <?php echo e($data['user']->user_type); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coregen1/www/expodisco/resources/views/user/dashboard.blade.php ENDPATH**/ ?>