<div class="profile-sidebar">
    <?php
        if($data['user']->profile_pic!=''){
            $profile_pic=url('uploads/profile_pics/'.$data['user']->profile_pic);
        } else{
            $profile_pic=url('uploads/profile_pics/default-profile.png');
        }
        ?>
	<div class="profile-img" style="background-image: url('<?php echo e($profile_pic); ?>') ">
    </div>
	<div class="profile-display-name"><?php echo e($data['user']->name); ?></div>
    <div class="profile-display-type"><?php echo e(str_replace('_',' ',$data['user']->user_type)); ?></div>
</div>
<div class="logged-in-usermenus">
	<ul>
        <li><a href="<?php echo e(route('edit-profile')); ?>"><i class="fas fa-user"></i> Manage Profile</a></li>
        <?php if($data['user']->user_type=='vendor'): ?>
        <!-- <li><a href="<?php echo e(route('edit-profile-gallery')); ?>"><i class="fas fa-calendar-week"></i> Gallery</a></li> -->
        <?php endif; ?>
        <?php if($data['user']->user_type!='customer'): ?>
    		<li><a href="<?php echo e(route('my-event-calender')); ?>"><i class="fas fa-calendar-week"></i> My Event Calender</a></li>
            <li><a href="<?php echo e(route('event-calender')); ?>"><i class="fas fa-calendar-week"></i> Event Calender</a></li>
        <?php else: ?>
            <li><a href="<?php echo e(route('event-calender')); ?>"><i class="fas fa-calendar-week"></i> Event Calender</a></li>
        <?php endif; ?>
        <!-- <li><a href="<?php echo e(route('logout')); ?>"><i class="fas fa-sign-out-alt"></i> 
         Logout</a></li> -->
		<!-- <li><a href=""><i class="fa fa-folder fa-fw" aria-hidden="true"></i> Advertisements</a></li>
        <li><a href=""><i class="fa fa-bookmark fa-fw" aria-hidden="true"></i> Membership Plans</a></li>
        <li><a href=""><i class="fa fa-envelope fa-fw" aria-hidden="true"></i> Email Notification</a></li>
        <li><a href=""><i class="fa fa-star fa-fw" aria-hidden="true"></i> Review Rating</a></li> -->

	</ul>
</div><?php /**PATH /home/coregen1/www/expodisco/resources/views/template-part/sidebar.blade.php ENDPATH**/ ?>