<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2><?php echo e($data['page_title']); ?></h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span><?php echo e($data['page_title']); ?></span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                        <a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss></a>
                    </div>

                    <h2 class="panel-title">Pages</h2>
                </header>
                <div class="panel-body">

                    <?php if(!empty($data['pages'])): ?>
                    <table class="table table-bordered table-striped mb-none" id="example">
                        <thead>
                            <tr>
                                <th>SL No</th>
                                <th>Page</th>
                                <th>Created At</th>
                                <th >Action</th>
                                
                            </tr>
                        </thead>
                        <tbody>

                        <?php $counter=1; ?>
                        <?php $__currentLoopData = $data['pages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="gradeX">
                                <td><?php echo e($counter); ?></td>
                                <td><?php echo e($page->page_name); ?></td>
                                <td><?php echo e($page->created_at); ?></td>
                                <td class="center">4</td>
                               
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <?php echo e(__('No Data Found')); ?>


                    <?php endif; ?>


                    
                </div>
            </section>


        </div>
    </div>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coregen1/www/expodisco/resources/views/admin/pages.blade.php ENDPATH**/ ?>