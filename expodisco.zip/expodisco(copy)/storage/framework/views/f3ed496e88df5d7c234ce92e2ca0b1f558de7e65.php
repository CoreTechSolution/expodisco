<div class="event-sidebar">
    
    <?php if(!empty($event_verticals)): ?>
        <h3>Event Verticals</h3>
        <ul>
            <?php $__currentLoopData = $event_verticals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event_vertical): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url('event-verticals/'.$event_vertical->slug)); ?>"><?php echo e($event_vertical->event_verticals_name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</div><?php /**PATH /home/coregen1/www/expodisco/resources/views/template-part/event_sidebar.blade.php ENDPATH**/ ?>