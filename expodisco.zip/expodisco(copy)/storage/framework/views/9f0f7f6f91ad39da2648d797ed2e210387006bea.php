<?php $__env->startSection('content'); ?>

<div class="section">
    <div class="container">
        <div class="row">

            <!-- <div class="col-lg-3">
               <?php echo $__env->make('template-part.event_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               
           </div> -->
           <?php
           
            /* $vendor_category=Helper::get_returnvaluefield('vendor_categories','id',Helper::get_user_meta($data['vendor']->id,'vendor_category',true),'vendor_category_name');

            $service_area=Helper::get_returnvaluefield('cities','id',Helper::get_user_meta($data['vendor']->id,'service_area',true),'city_name');
            $company__detals=Helper::get_user_by('id',$data['vendor']->company);
            $products=Helper::get_products_by_user($data['vendor']->id);
            $services=Helper::get_services_by_user($data['vendor']->id); */
            if(!empty($data['company']->profile_pic)){
                $bg_image=url($data['company']->profile_pic);
            } else{
                $bg_image=url('uploads/no_images.png');
            }
            
           ?>
           <div class="col-lg-12">
            <div class="page_content">
                <div class="bg-image" style="background-image: url(
                '<?php echo e($bg_image); ?>'); background-size: cover; background-position: center;"></div>

                <div class="bg-text">
                  <div class="vendor_details_profile_img" style="background: url(<?php echo e($bg_image); ?>); background-size: cover; background-position: center;">
                      
                  </div>
                  <div class="vendor_bg_detail_text">
                      <h1><?php echo e($data['company']->name); ?></h1>
                      <p><?php echo e($data['company']->email); ?></p>
                     
                  </div>
                  
                </div>
                <div class="breadcrumbs_div">
                    <ul class="breadcrumbs">
                        <li class="first"><a href="<?php echo e(url('/')); ?>" class="fa fa-home"></a></li>
                        <?php if(!empty(Request::segment(1))): ?>
                            <?php if(empty(Request::segment(2))): ?>
                                <li class="last active"><a href="javascript:void(0)"><?php echo e(Request::segment(1)); ?></a></li>
                            <?php else: ?>
                                <li><a href="<?php echo e(url('companies')); ?>"><?php echo e(Request::segment(1)); ?></a></li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(!empty(Request::segment(2))): ?>
                            <?php if(empty(Request::segment(3))): ?>
                                <li class="last active"><a href="javascript:void(0)"><?php echo e(Helper::get_returnvaluefield('users','id',Request::segment(2),'name')); ?></a></li>
                            <?php else: ?>
                                <li><a href="<?php echo e(url('companies/'.Request::segment(2))); ?>"><?php echo e(Request::segment(2)); ?></a></li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(!empty(Request::segment(3))): ?>
                            <?php if(empty(Request::segment(4))): ?>
                                <li class="last active"><a href="javascript:void(0)"><?php echo e(Request::segment(3)); ?></a></li>
                            <?php else: ?>
                                <li><a href="<?php echo e(url('vendors/'.Request::segment(2).'/'.Request::segment(3))); ?>"><?php echo e(Request::segment(3)); ?></a></li>
                            <?php endif; ?>
                        <?php endif; ?>
                       
                        
                    </ul>
                </div>
              
                <div class="vendor_page_body">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="section_text">
                                <h2>About</h2>
                                <?php echo e(Helper::get_user_meta($data['company']->id,'description',true)); ?>    
                            </div>

                            <?php
                                $gallery_images=array();
                                $gallery_images=Helper::get_user_meta($data['company']->id,'gallaries',true);
                                if(!empty($gallery_images))
                                $gallery_images=unserialize($gallery_images);
                                //print_r
                            ?>
                            <?php if(!empty($gallery_images)): ?>
                            <div class="section_text">
                                <h2>Gallery</h2>
                                <ul class="vendors_gallery_list parent-image-container">
                                <?php $__currentLoopData = $gallery_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($gallery)): ?>
                                    <li><a href="<?php echo e(url($gallery)); ?>"><img src="<?php echo e(url($gallery)); ?>" alt=""></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            <?php
                                //$events=Helper::get_event_by_user()
                            ?>

                            <div class="section_text event_list_tab">
                                <h2>Event Calendar</h2>
                                <ul class="nav nav-tabs" role="tablist">
                                    <li class="nav-item"><a class="nav-link mbr-fonts-style display-7 active" role="tab" data-toggle="tab" href="#sponsor" aria-expanded="true">
                                            Sponsor
                                        </a></li>
                                    <li class="nav-item"><a class="nav-link mbr-fonts-style display-7" role="tab" data-toggle="tab" href="#exibitor" aria-expanded="false">
                                            Exhibitor
                                        </a></li>
                                    <li class="nav-item"><a class="nav-link mbr-fonts-style display-7" role="tab" data-toggle="tab" href="#attendee" aria-expanded="false">
                                            Attendee
                                        </a></li>
                                    <li class="nav-item"><a class="nav-link mbr-fonts-style display-7" role="tab" data-toggle="tab" href="#speaker" aria-expanded="false">
                                            Speaker
                                        </a></li>
                                </ul>

                                <div class="tab-content">
                                    <div id="sponsor" class="tab-pane in active" role="tabpanel" aria-expanded="true">
                                        <?php
                                            $sponsors=Helper::get_event_by_user($data['company']->id,'sponsor');
                                        ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <?php if(!empty($sponsors)): ?>
                                                    <table class="table table-striped table-responsive ">
                                                        <tbody>
                                                            <?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td style="width:20%;text-align:right"><?php echo e(Helper::date_formate_change($sponsor->event_date_start,'d')); ?> - <?php echo e(Helper::date_formate_change($sponsor->event_date_end,'d M')); ?><small class="text-muted block"><?php echo e(Helper::date_formate_change($sponsor->event_date_end,'Y')); ?></small></td>
                                                                <td style="width:60%;"> <a href="<?php echo e(url('event-details/'.$sponsor->slug)); ?>"><strong><?php echo e($sponsor->event_title); ?></strong></a>
                                                                    <br><small class="text-success">SPONSOR</small><small class="text-muted">  <!-- 1491 Interested | 570 Going --></small></td>
                                                                <td style="width:20%;"><small class="block"><?php echo e($sponsor->event_country); ?></small></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                <?php else: ?>
                                                    <p class="mbr-text py-5 mbr-fonts-style display-7">
                                                        No Event found!
                                                    </p>
                                                <?php endif; ?>
                                                
                                            </div>
                                        </div>

                                    </div>
                                    <div id="exibitor" class="tab-pane" role="tabpanel" aria-expanded="false">
                                        <?php
                                            $exhibitors=Helper::get_event_by_user($data['company']->id,'exhibitor');
                                        ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <?php if(!empty($exhibitors)): ?>
                                                    <table class="table table-striped table-responsive ">
                                                        <tbody>
                                                            <?php $__currentLoopData = $exhibitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exhibitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td style="width:20%;text-align:right"><?php echo e(Helper::date_formate_change($exhibitor->event_date_start,'d')); ?> - <?php echo e(Helper::date_formate_change($exhibitor->event_date_end,'d M')); ?><small class="text-muted block"><?php echo e(Helper::date_formate_change($exhibitor->event_date_end,'Y')); ?></small></td>
                                                                <td style="width:60%;"> <a href="<?php echo e(url('event-details/'.$exhibitor->slug)); ?>"><strong><?php echo e($exhibitor->event_title); ?></strong></a>
                                                                    <br><small class="text-success">EXHIBITOR</small><small class="text-muted">  <!-- 1491 Interested | 570 Going --></small></td>
                                                                <td style="width:20%;"><small class="block"><?php echo e($exhibitor->event_country); ?></small></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                <?php else: ?>
                                                    <p class="mbr-text py-5 mbr-fonts-style display-7">
                                                        No Event found!
                                                    </p>
                                                <?php endif; ?>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div id="attendee" class="tab-pane" role="tabpanel" aria-expanded="false">
                                        <?php
                                            $attendees=Helper::get_event_by_user($data['company']->id,'attendee');
                                        ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <?php if(!empty($attendees)): ?>
                                                    <table class="table table-striped table-responsive ">
                                                        <tbody>
                                                            <?php $__currentLoopData = $attendees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td style="width:20%;text-align:right"><?php echo e(Helper::date_formate_change($attendee->event_date_start,'d')); ?> - <?php echo e(Helper::date_formate_change($attendee->event_date_end,'d M')); ?><small class="text-muted block"><?php echo e(Helper::date_formate_change($attendee->event_date_end,'Y')); ?></small></td>
                                                                <td style="width:60%;"> <a href="<?php echo e(url('event-details/'.$attendee->slug)); ?>"><strong><?php echo e($attendee->event_title); ?></strong></a>
                                                                    <br><small class="text-success">ATTENDEE</small><small class="text-muted">  <!-- 1491 Interested | 570 Going --></small></td>
                                                                <td style="width:20%;"><small class="block"><?php echo e($attendee->event_country); ?></small></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                <?php else: ?>
                                                    <p class="mbr-text py-5 mbr-fonts-style display-7">
                                                        No Event found!
                                                    </p>
                                                <?php endif; ?>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div id="speaker" class="tab-pane" role="tabpanel" aria-expanded="false">
                                        <?php
                                            $speakers=Helper::get_event_by_user($data['company']->id,'speaker');
                                        ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <?php if(!empty($speakers)): ?>
                                                    <table class="table table-striped table-responsive ">
                                                        <tbody>
                                                            <?php $__currentLoopData = $speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speaker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td style="width:20%;text-align:right"><?php echo e(Helper::date_formate_change($speaker->event_date_start,'d')); ?> - <?php echo e(Helper::date_formate_change($speaker->event_date_end,'d M')); ?><small class="text-muted block"><?php echo e(Helper::date_formate_change($speaker->event_date_end,'Y')); ?></small></td>
                                                                <td style="width:60%;"> <a href="<?php echo e(url('event-details/'.$speaker->slug)); ?>"><strong><?php echo e($speaker->event_title); ?></strong></a>
                                                                    <br><small class="text-success">SPEAKER</small><small class="text-muted">  <!-- 1491 Interested | 570 Going --></small></td>
                                                                <td style="width:20%;"><small class="block"><?php echo e($speaker->event_country); ?></small></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                <?php else: ?>
                                                    <p class="mbr-text py-5 mbr-fonts-style display-7">
                                                        No Event found!
                                                    </p>
                                                <?php endif; ?>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            

                        </div>

                         <?php //print_r($data['company']); exit; ?>
                        
                    </div>
                    
                    

              </div>
        </div>
    </div>
</div>
</div>
</div>

<!-- Modal -->
<div class="modal fade" id="company_details" tabindex="-1" role="dialog" aria-labelledby="companyModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="companyModalLabel">Company Name</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="model_body_content">
       

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coregen1/www/expodisco/resources/views/comapny_details.blade.php ENDPATH**/ ?>