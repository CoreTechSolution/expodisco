<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2><?php echo e($data['page_title']); ?></h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span><?php echo e($data['page_title']); ?></span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-lg-12">
            <div class="section_head">
                <div class="button_div pull-right">
                    <ul>
                        <!-- <li><a href="<?php echo e(route('admin.import_vendor_category')); ?>" class="btn btn-success">import from CSV</a></li> -->
                        <li><a href="<?php echo e(route('admin.add_vendor_testimonials')); ?>" class="btn btn-success">Add Testimonials</a></li>
                    </ul>
                </div>
            </div>
            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                        <a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss></a>
                    </div>

                    <h2 class="panel-title"><?php echo e($data['page_title']); ?></h2>
                </header>
                <div class="panel-body">

                    <?php if(!empty($data['vendor_testimonials'])): ?>
                    <table class="table table-bordered table-striped mb-none" id="example">
                        <thead>
                            <tr>
                                <th>SL No</th>
                                <th>Vendor</th>
                                <th>User</th>
                                <th>Content</th>
                                <th>Created At</th>
                                <th>Action</th>
                                
                            </tr>
                        </thead>
                        <tbody>

                        <?php $counter=1; ?>
                        <?php $__currentLoopData = $data['vendor_testimonials']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor_testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="gradeX">
                                <td><?php echo e($counter); ?></td>
                                <td><?php echo e(Helper::get_returnvaluefield('users','id',$vendor_testimonial->vendor_id,'name')); ?></td>
                                <td><?php echo e($vendor_testimonial->user_name); ?></td>
                                <td><?php echo e(str_limit($vendor_testimonial->content,60)); ?></td>
                                <td><?php echo e($vendor_testimonial->created_at); ?></td>
                                <td class="center">
                                    <a title="Edit" href="<?php echo e(url('admin/edit_vendor_testimonials/'.$vendor_testimonial->id)); ?>" class="btn btn-sm btn-sm-me btn-success"><i class="fa fa-pencil-square-o"></i></a>
                   
                                </td>
                               
                            </tr>
                            <?php $counter++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <?php echo e(__('No Data Found')); ?>


                    <?php endif; ?>


                    
                </div>
            </section>


        </div>
    </div>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coregen1/www/expodisco/resources/views/admin/vendor_testimonials.blade.php ENDPATH**/ ?>