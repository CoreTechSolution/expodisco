/*
Name: 			Dashboard - Examples
Written by: 	Okler Themes - (http://www.okler.net)
Theme Version: 	1.4.1
*/

$(document).ready(function() {
    $('#example').DataTable();
} );


